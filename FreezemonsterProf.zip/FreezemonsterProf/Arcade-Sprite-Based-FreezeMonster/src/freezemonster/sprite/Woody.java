package freezemonster.sprite;

import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

import freezemonster.Commons;

public class Woody extends spriteframework.sprite.PlayerXY {
	private  int width;
    private int height;
    

	public Woody() {
	// TODO Auto-generated constructor stub
}
	@Override 
	protected void loadImage () {
	        ImageIcon ii = new ImageIcon("images/woody.png");
	        Image scaledImage = ii.getImage().getScaledInstance(38, 78, Image.SCALE_SMOOTH);
	        width = scaledImage.getWidth(null);
	        
	        height = scaledImage.getHeight(null);
	        setImage(scaledImage);
	    }
	 	
	
}
