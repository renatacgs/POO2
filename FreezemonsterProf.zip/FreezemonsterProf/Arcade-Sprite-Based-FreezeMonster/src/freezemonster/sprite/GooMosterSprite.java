package freezemonster.sprite;

import java.awt.Image;
import java.util.LinkedList;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;
import spriteframework.sprite.BadnessBoxSprite;

public class GooMosterSprite extends BadnessBoxSprite {
	private int height;
    private int width;
    

    private GooMonster gosma;
    private int monsterIndex;
    
    public GooMosterSprite(int x, int y, int monsterIndex) {
       this.monsterIndex = monsterIndex;
       super.qualMonstro=monsterIndex;
        initMonster(x, y);
    }

    private void initMonster(int x, int y) {

        this.x = x;
        this.y = y;

        gosma = new GooMonster(x, y);

        String alienImg = "images/monster" + monsterIndex + ".png";
        ImageIcon ii = new ImageIcon(alienImg);
        Image scaledImage = ii.getImage().getScaledInstance(40, 65, Image.SCALE_SMOOTH);

        setImage(scaledImage);
        height = scaledImage.getHeight(null);
        width = scaledImage.getWidth(null);

    }

    public GooMonster getGosma() {

        return gosma;
    }

    @Override
    public LinkedList<BadSprite> getBadnesses() {
        LinkedList<BadSprite> aRay = new LinkedList<BadSprite>();
        aRay.add(gosma);
        return aRay;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
    
    @Override
    public void die(){
        String alienImg = "images/monster" + monsterIndex + "bg.png";
        ImageIcon ii = new ImageIcon(alienImg);
        Image scaledImage = ii.getImage().getScaledInstance(40, 65, Image.SCALE_SMOOTH);

        setImage(scaledImage);
        
        setDying(true);
    }

	

}
