package freezemonster.sprite;

import java.awt.Image;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;

public class Ray  extends BadSprite{
	private int height;
    private int width;

    public Ray() {
    }

    public Ray(int x, int y) {

        initShot(x, y);
    }

    private void initShot(int x, int y) {

        String shotImg = "images/ray.png";
        ImageIcon ii = new ImageIcon(shotImg);
        Image scaledImage = ii.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        setImage(scaledImage);

        int H_SPACE = 6;
        setX(x + H_SPACE);

        int V_SPACE = 1;
        setY(y - V_SPACE);
        
        height = scaledImage.getHeight(null);
        width = scaledImage.getWidth(null);
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }


}
