package freezemonster;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.Random;

import javax.swing.ImageIcon;

import freezemonster.sprite.GooMonster;
import freezemonster.sprite.GooMosterSprite;
import freezemonster.sprite.Ray;
import freezemonster.sprite.Woody;
import spriteframework.AbstractBoard;
import spriteframework.sprite.BadSprite;
import spriteframework.sprite.PlayerXY;

public class FreezeMonsterBoard extends AbstractBoard {
	
	public FreezeMonsterBoard() {

	}

	// define sprites
	// private List<BadSprite> aliens;
	private Ray ray;

	// define global control vars
	private int direction = -1;
	private int deaths = 0;
	private int rayDx = 1;
	private int rayDy = 0;

	private String explImg = "images/explosion.png";

	@Override
	protected void createBadSprites() { // create sprites
		Random random = new Random();
		for (int i = 0; i < 8; i++) { //roda ate criar os 8 monstrinhos

			GooMosterSprite monster = new GooMosterSprite((int) (random.nextFloat() * (Commons.BOARD_WIDTH - 65)),
					(int) (random.nextFloat() * (Commons.BOARD_HEIGHT - 40)), i + 1);

			// implementar nascer em lugar aleatorio

			int somaxy = 0;
			int newDx = 0;
			int newDy = 0;
			while (somaxy == 0) {
				newDy = random.nextInt(3) - 1;
				newDx = random.nextInt(3) - 1;
				somaxy = newDy + newDx;
			}
			monster.setDx(newDx);
			monster.setDy(newDy);
			badSprites.add(monster);

		}
	}

	@Override
	protected void createOtherSprites() {
		ray = new Ray();
	}

	private void drawShot(Graphics g) { //vai desenhar o tiro dado 

		if (ray.isVisible()) {

			g.drawImage(ray.getImage(), ray.getX(), ray.getY(), this);
		}
	}

	// Override
	@Override
	protected void drawOtherSprites(Graphics g) {
		drawShot(g);
	}

	@Override
	protected void processOtherSprites(spriteframework.sprite.PlayerXY player, KeyEvent e) {
		int x = player.getX();
		int y = player.getY();

		int key = e.getKeyCode();

		if (key == KeyEvent.VK_SPACE) {

			if (inGame) {

				if (!ray.isVisible()) {

					ray = new Ray(x, y);
				}
			}
		}
	}

	@Override
	protected void update() {
		System.out.println(deaths);

		if (deaths >= Commons.NUMBER_OF_MONSTERS_TO_DESTROY) {

			inGame = false;
			timer.stop();
			message = "Game won!"; //se o numero de mortos foi maior ou igual o de monstros vc ganha o jogo
		}

		// player
		for (PlayerXY player : players) {
			player.action(); 
		}

		// shot
		for (PlayerXY player : players) {
			if (ray.isVisible()) { // processa a colisao

				int rayx = ray.getX();
				int rayy = ray.getY();
				

				for (BadSprite monster : badSprites) {
					
					int monsterx = monster.getX();
					int monstery = monster.getY();

					if (monster.isFreeze()==false && ray.isVisible()) {
						if (rayx >= (monsterx) && rayx <= (monsterx + monster.getImageWidth()) && rayy >= (monstery)
								&& rayy <= (monstery + monster.getImageHeight())) {

							ImageIcon ii = new ImageIcon("images/monster"+monster.qualMonstro+"bg.png");
							System.out.println("este � o monstro "+monster.qualMonstro);
					        Image scaledImage = ii.getImage().getScaledInstance(40, 65, Image.SCALE_SMOOTH);
							monster.setImage(scaledImage);
							
//	                            monster.setImage(ii.getImage());

							if (!monster.isDying()) {
								deaths++;
							}

							
							monster.setFreeze(true);
							System.out.println("raio morreu");
							ray.die();

						}
					}
				}

			}

			// set ray new position

			int y = ray.getY();
			int x = ray.getX();
			int lastKey = player.lastKeyPressed;

			if (ray.isVisible()) {
				if (y >= Commons.BOARD_HEIGHT - (ray.getHeight() * 9) || y <= 0
						|| x >= Commons.BOARD_WIDTH - (ray.getWidth() * 6) || x <= 0) {
					ray.die();
					ray.setDying(true);
				} else {

					ray.setX(ray.getX() + rayDx);
					ray.setY(ray.getY() + rayDy);
				}
			} else {

				switch (lastKey) {
				case KeyEvent.VK_RIGHT:
					rayDx = 12;
					rayDy = 0;
					break;
				case KeyEvent.VK_LEFT:
					rayDx = -12;
					rayDy = 0;
					break;
				case KeyEvent.VK_DOWN:
					rayDy = 12;
					rayDx = 0;
					break;
				case KeyEvent.VK_UP:
					rayDy = -12;
					rayDx = 0;
					break;
				default:
					break;
				}
			}

		}

		// aliens
		Random random = new Random();
		for (BadSprite monster : badSprites) {
			if (!monster.isFreeze()) {
				if (1 == random.nextInt(100)) {
					int sunDxDy = 0;
					int newDx = 0;
					int newDy = 0;
					while (sunDxDy == 0) {
						newDx = (random.nextInt(3) - 1) * 1;
						newDy = (random.nextInt(3) - 1) * 1;
						sunDxDy = newDx + newDy;
					}

					monster.setDx(newDx);
					monster.setDy(newDy);
				}

				else {
					monster.getImageDimensions();

					if (monster.getY() >= Commons.BOARD_HEIGHT - 100 || monster.getY() <= 0) {
						monster.setDy(monster.getDy() * -1);
					}

					if (monster.getX() >= Commons.BOARD_WIDTH - 45 || monster.getX() <= 0) {
						monster.setDx(monster.getDx() * -1);
					}

				}

				monster.setX(monster.getX() + monster.getDx());
				monster.setY(monster.getY() + monster.getDy());
			}
		}

		// bombs
		updateOtherSprites();
	}

	protected void updateOtherSprites() {
		Random generator = new Random();

		for (BadSprite monster : badSprites) {

			int shot = generator.nextInt(15);
			GooMonster gosma = ((GooMosterSprite) monster).getGosma();

			if (shot == Commons.CHANCE && !monster.isDying() && gosma.isDestroyed()) {

				gosma.setDestroyed(false);
				gosma.setX(monster.getX());
				gosma.setY(monster.getY());
				gosma.setDx(monster.getDx() * -2);
				gosma.setDy(monster.getDy() * -2);
			}

			int gosmax = gosma.getX();
			int gosmay = gosma.getY();
			int playerX = players.get(0).getX();
			int playerY = players.get(0).getY();

			if (players.get(0).isVisible() && !gosma.isDestroyed()) {

				if (gosmax >= (playerX) && gosmax <= (playerX + Commons.PLAYER_WIDTH) && gosmay >= (playerY)
						&& gosmay <= (playerY + Commons.PLAYER_HEIGHT)) {

					ImageIcon ii = new ImageIcon(explImg);
					players.get(0).setImage(ii.getImage());
					players.get(0).setDying(true);
					gosma.setDestroyed(true);
				}
			}

			if (!gosma.isDestroyed()) {
				gosma.setY(gosmay + gosma.getDy());
				gosma.setX(gosmax + gosma.getDx());

				if (gosma.getY() >= Commons.BOARD_HEIGHT - 60 || gosma.getX() >= Commons.BOARD_WIDTH - 35
						|| gosma.getX() <= 0 || gosma.getY() <= 0) {

					gosma.setDestroyed(true);
				}

			}

			if (!gosma.isDestroyed()) {
				if (gosmax >= (ray.getX() - 10) && gosmax <= (ray.getX() + 10) && gosmay >= (ray.getY() - 10)
						&& gosmay <= (ray.getY() + 10)) {
					ray.die();
					gosma.setDestroyed(true);
				}
			}
		}
	}

	@Override
	protected void setBoardColor(Graphics g) {
		
		g.setColor(Color.green);
        g.fillRect(0, 0, d.width, d.height);

	}

	@Override
	protected PlayerXY PlayerCria() {
		return new Woody();
	}

}