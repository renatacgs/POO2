package freezemonster;

import java.awt.EventQueue;

import spriteframework.AbstractBoard;
import spriteframework.MainFrame;

public class FreezeMosterGame extends MainFrame {

	public FreezeMosterGame() {
		super("Freeze Monster Game");
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected AbstractBoard createBoard() {
		// TODO Auto-generated method stub
		return new FreezeMonsterBoard();
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {

			new FreezeMosterGame();
		});
	}

}
