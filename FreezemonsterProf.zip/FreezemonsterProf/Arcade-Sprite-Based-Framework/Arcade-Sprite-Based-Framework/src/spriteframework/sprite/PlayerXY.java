package spriteframework.sprite;
import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

import spriteframework.Commons;

public class PlayerXY extends Sprite{
	private  int width;
    private int height;
    public int lastKeyPressed;
    

    public  PlayerXY() {
			loadImage();
		getImageDimensions();
		resetState();
    }

 
	protected void loadImage () {
	        ImageIcon ii = new ImageIcon("images/woody.png");
	        Image scaledImage = ii.getImage().getScaledInstance(38, 78, Image.SCALE_SMOOTH);
	        width = scaledImage.getWidth(null);
	        
	        height = scaledImage.getHeight(null);
	        setImage(scaledImage);
	    }
	 public void action() {
	        x += dx;
	        y += super.dy;
	        if (x <= 2) {

	            x = 2;
	        }
	        
	        if (y <= 2) {

	            y = 2;
	        }

	        if (x >= Commons.BOARD_WIDTH - (width * 2)) {
	            x = Commons.BOARD_WIDTH - (width * 2);
	        }
	        
	        if (y >= Commons.BOARD_HEIGHT - (height * 5)) {
	            y = Commons.BOARD_HEIGHT - (height * 5);
	        }	
		}

	    public void keyPressed(KeyEvent e) {

	        int key = e.getKeyCode();
          this.lastKeyPressed = key;
	        
	        if (key == KeyEvent.VK_LEFT) {
	            dx = -2;
	        }

	        if (key == KeyEvent.VK_RIGHT) {

	            dx = 2;
	        }
	        
	        if (key == KeyEvent.VK_UP) {
	            dy = -2;
	        }
	        
	        if (key == KeyEvent.VK_DOWN) {
	            dy = 2;
	        }
	    }

	    public void keyReleased(KeyEvent e) {

	        int key = e.getKeyCode();

	        if (key == KeyEvent.VK_LEFT) {

	            dx = 0;
	        }

	        if (key == KeyEvent.VK_RIGHT) {

	            dx = 0;
	        }
	        
	        if (key == KeyEvent.VK_UP) {
	            dy = 0;
	        }
	        
	        if (key == KeyEvent.VK_DOWN) {
	            dy = 0;
	        }
	    }
	    private void resetState() {

	        setX(Commons.INIT_PLAYER_X);
	        setY(Commons.INIT_PLAYER_Y);
	    }
	

}
