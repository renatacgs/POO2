abstract class Command {
    abstract public void Redo();
    abstract public void Undo();
}
