package com.iluwatar.abstractfactory;


public interface Castle {

  String getDescription();
}