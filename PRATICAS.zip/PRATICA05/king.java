package com.iluwatar.abstractfactory;

public interface King {

  String getDescription();
}