package entity;

public enum TipoUnidade {
    KG, UN, MT;
}
