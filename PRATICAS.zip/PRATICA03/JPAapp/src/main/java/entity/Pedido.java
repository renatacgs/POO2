package entity;
import java.util.*;
public class Pedido {
	Cliente cliente;
	LinkedList<ItemCompra> itensComprados;
	float totalPedido;
	
	public Pedido (Cliente c) {
		this.cliente = c;
		itensComprados = new LinkedList<ItemCompra>();
		totalPedido = 0;
	}
    public float getTotalPedido() {
		return totalPedido;
	}

	public void setTotalPedido(float totalPedido) {
		this.totalPedido = totalPedido;
	}
	
	public void adicionaAoTotal (float valor) {
		totalPedido += valor;
	}
    
    public void addItem (ItemCompra item) {
    	itensComprados.add(item);
    }
}
