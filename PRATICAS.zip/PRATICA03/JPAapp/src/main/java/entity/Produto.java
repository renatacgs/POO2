package entity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "produto")
@NamedQueries({
    @NamedQuery(name = "Produto.findByDesc",
            query = "SELECT p FROM Produto b WHERE p.descricao = :descricao")
})
public class Produto {
	
    @Id
    @Column(name = "codigo")	
	private int    codigo;
    
    @Column(name = "descricao")
	private String descricao;
    
    @Column(name = "preco_bruto_venda")
	private float  precoBrutoVendaUnitario;
    
    @Column(name = "estoque")
	private float  estoque;
    
    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL)
    private List<Promocao> promocoes = new ArrayList<Promocao>();
    
	public Produto (int c, String desc, float precoBruto, float estoque) {
		codigo = c;
		descricao = desc;
		precoBrutoVendaUnitario = precoBruto;
		this.estoque = estoque;
	}
	
	public void addPromo(Promocao p) {
		promocoes.add(p);
		p.setProd(this);
	}
	
	public void  removePromo (Promocao p) {
		promocoes.remove(p);
		p.setProd(null);
	}
	
	public int getCodigo() {
		return codigo;
	}
	
    public String getDescricao () {
    	return descricao;
    }

	public float getPrecoBrutoVendaUnitario() {
		return precoBrutoVendaUnitario;
	}

	public void baixaEstoque (float valor) {
		estoque -= valor;
	}

	public float precoComDesconto (LocalDate d) {
		for (Promocao p: promocoes)
			if (p.isAtiva(d))
		        return this.precoBrutoVendaUnitario - p.getValorDesconto(d);
		return this.precoBrutoVendaUnitario;
	}
	
	public List<Promocao> getPromocoes() {
		return promocoes;
	}

	public void setPromocoes(List<Promocao> promocoes) {
		this.promocoes = promocoes;
	}

	public float qtdeEstoque () {
		return estoque;
	}
	
	public String toString() {
		return "Cod: " + this.codigo + ", Desc: " + this.descricao + ", Preco: "
				+ this.precoBrutoVendaUnitario + ", Estoque: " + this.estoque;
	}
}
