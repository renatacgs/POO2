package entity;
import java.time.LocalDate;
import java.util.*;
public class Carrinho {
	private Cliente cliente;
	private LinkedList<ItemCompra> listaItens;

	
	public Carrinho (Cliente c) {
		this.cliente = c;
	}

	public boolean atualizaQtde (Produto p, float novaQtde) {
		for (ItemCompra item: listaItens) {
			if (item.getCodigoProduto() == p.getCodigo()) {
				item.atualizaQuantidade(novaQtde);
				return true;
			}
		}
		return false;
	}
	
	public void addItem (Produto p, float qtde) {
        if (atualizaQtde(p, qtde))   // garante que não haverá duplicados
            return;
        ItemCompra item = new ItemCompra(p, qtde);
        listaItens.add(item);
	}
	
	public float totalCarrinho () {
		float total = 0;
		for (ItemCompra item: listaItens) {
			total += item.getValorItemSemDesconto();
		}
		return total;
	}
	
	public void fechaPedido () {
		Pedido pedido = new Pedido(this.cliente);
		for (ItemCompra item: listaItens) {
			if (item.temEstoqueSuficiente()) {
 			    pedido.addItem(item);
			    pedido.adicionaAoTotal(item.getValorItemComDesconto(LocalDate.now()));
			}
			else
				return;
		}
		cliente.incluiPedido(pedido);
	}
}
