package entity;
import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import java.time.LocalDate;

@Entity

@Table(name = "promocao", 
       uniqueConstraints=
	        @UniqueConstraint(columnNames={"cod_produto", "data_inicio"})
	)
public class Promocao implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue
    private int Id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="cod_produto")
    private Produto produto;

    @Column(name = "data_inicio")
    LocalDate dataInicio;    
    
    @Column(name = "perc_desconto")	
	float percDesconto;
    
	@Column(name = "dias_ativa")	
	int diasAtiva;

    public Produto getProduto() {
		return produto;
	}

	public void setProd(Produto prod) {
		this.produto = prod;
	}

	public float getPercDesconto() {
		return percDesconto;
	}

	public void setPercDesconto(float percDesconto) {
		this.percDesconto = percDesconto;
	}

	public LocalDate getDataFim () {
		return this.dataInicio.plusDays(diasAtiva);
	}
	
	public boolean isAtiva(LocalDate data) {
		return data.isAfter(dataInicio) && data.isBefore(dataInicio.plusDays(diasAtiva));
	}


	public Promocao (Produto p, float pDesconto, LocalDate dataInicio, int diasAtiva) {
	    this.produto = p;
		this.percDesconto = pDesconto;
		this.dataInicio = dataInicio;
		this.diasAtiva = diasAtiva;
	}
	
	public int getCodProduto () {
		return produto.getCodigo();
	}
	
	public float getValorDesconto (LocalDate date) {
		return isAtiva(date) ? produto.getPrecoBrutoVendaUnitario() * percDesconto : 0;
	}

}
