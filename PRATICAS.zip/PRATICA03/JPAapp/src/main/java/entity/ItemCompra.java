package entity;

import java.time.LocalDate;

public class ItemCompra {
	private Produto produto;
	private float   quantidade;
	
	public ItemCompra (Produto produto, float qtde) {
		this.produto = produto;
		this.quantidade = qtde;
	}
	
	public int getCodigoProduto () {
		return produto.getCodigo();
	}
	
	public float getValorItemSemDesconto () {
		return quantidade * produto.getPrecoBrutoVendaUnitario();
	}
	
	public float getValorItemComDesconto (LocalDate d) {
		return quantidade * produto.precoComDesconto(d);
	}
	
	public boolean temEstoqueSuficiente () {
		return produto.qtdeEstoque() >= this.quantidade;
	}
	
	public float getQuantidade () {
		return quantidade;
	}
	
	public void atualizaQuantidade (float qtde) {
		this.quantidade = qtde;
	}
}
