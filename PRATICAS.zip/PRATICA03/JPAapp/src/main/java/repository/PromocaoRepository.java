package repository;
import javax.persistence.EntityManager;

import entity.Produto;
import entity.Promocao;

import java.util.List;
import java.util.Optional;

public class PromocaoRepository {
    private EntityManager entityManager;

    public PromocaoRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Optional<Promocao> save(Promocao promocao) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(promocao);
            entityManager.getTransaction().commit();
            return Optional.of(promocao);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public Optional<Promocao> findById(Integer id) {
        Promocao promocao = entityManager.find(Promocao.class, id);
        return promocao != null ? Optional.of(promocao) : Optional.empty();
    }

    public List<Promocao> findAll() {
        return entityManager.createQuery("from Promocao").getResultList();
    }

    public Optional<List<Promocao>> findByProduto(Produto p) {
        List<Promocao> promocoes = entityManager.createQuery("SELECT p FROM Promocao p WHERE p.cod_produto = " + p.getCodigo(), Promocao.class)
        		                                .getResultList();
        return promocoes != null ? Optional.of(promocoes) : Optional.empty();
    }
}
