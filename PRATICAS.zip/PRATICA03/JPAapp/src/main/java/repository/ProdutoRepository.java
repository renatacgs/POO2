package repository;
import javax.persistence.EntityManager;

import entity.Produto;
import entity.Promocao;

import java.util.List;
import java.util.Optional;

public class ProdutoRepository {
    private EntityManager entityManager;

    public ProdutoRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Optional<Produto> save(Produto produto) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(produto);
            entityManager.getTransaction().commit();
            return Optional.of(produto);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public Optional<Produto> findById(Integer id) {
        Produto produto = entityManager.find(Produto.class, id);
        return produto != null ? Optional.of(produto) : Optional.empty();
    }

    public List<Produto> findAll() {
        return entityManager.createQuery("from Produto").getResultList();
    }

    public Optional<Produto> findByDesc(String d) {
        Produto produto = entityManager.createQuery("SELECT p FROM Produto p WHERE p.descricao = :desc", Produto.class)
                .setParameter("desc", d)
                .getSingleResult();
        return produto != null ? Optional.of(produto) : Optional.empty();
    }

    public Optional<Produto> findByNameNamedQuery(String d) {
        Produto produto = entityManager.createNamedQuery("Produto.findByDescricao", Produto.class)
                .setParameter("descricao", d)
                .getSingleResult();
        return produto != null ? Optional.of(produto) : Optional.empty();
    }
}
