
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity.Produto;
import entity.Promocao;
import repository.ProdutoRepository;
import repository.PromocaoRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class TesteJPASupermercado {
	public static void main(String args[]) {
		// Create our entity manager
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Produtos");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		// Create our repositories
		ProdutoRepository produtoRepository = new ProdutoRepository(entityManager);
		PromocaoRepository promocaoRepository = new PromocaoRepository(entityManager);
//    AuthorRepository authorRepository = new AuthorRepository(entityManager);
//
//    // Create an author and add 3 books to his list of books
//    Author author = new Author("Author 1");
//    author.addBook(new Book("Book 1"));
//    author.addBook(new Book("Book 2"));
//    author.addBook(new Book("Book 3"));
//    Optional<Author> savedAuthor = authorRepository.save(author);
//    System.out.println("Saved author: " + savedAuthor.get());
//

		Produto p1 = new Produto(1, "Chinelo de Dedo", 25.0f, 10.0f);
		Produto p2 = new Produto(2, "Pantufa", 30f, 5f);
		
		Optional<Produto> savedP1 = produtoRepository.save(p1);
		Optional<Produto> savedP2 = produtoRepository.save(p2);
		
		System.out.println("Saved p1 = " + savedP1.toString());
		System.out.println("Saved p2 = " + savedP2.toString());
		
		List<Produto> produtos = produtoRepository.findAll();

		System.out.println("________ Produtos: ________");
		for (Produto p: produtos)
			System.out.println(p);
		
		Promocao promo1 = new Promocao(p1, 0.10f, LocalDate.of(2020, 8, 28), 3);
		Promocao promo2 = new Promocao(p1, 0.20f, LocalDate.of(2019, 8, 25), 3);
		
		Optional<Promocao> savedPromo1 = promocaoRepository.save(promo1);
		Optional<Promocao> savedPromo2 = promocaoRepository.save(promo2);
		
		p1.addPromo(promo1);
		p1.addPromo(promo2);
		savedP1 = produtoRepository.save(p1);
		
	
		List<Promocao> promocoes = promocaoRepository.findAll();
		for (Promocao p: promocoes) {
			System.out.println("Promo: Prod: " + p.getProduto() + " - Desconto:" + p.getPercDesconto());
		}
		
		produtos = produtoRepository.findAll();		
		System.out.println("________ Produtos: ________");
		for (Produto p: produtos) {
			System.out.println(p + " Preco Com Desconto: " + p.precoComDesconto(LocalDate.now()));
			for (Promocao promo: p.getPromocoes()) {
				System.out.println("Promo: Prod: " + promo.getProduto() + " - Desconto:" + promo.getPercDesconto());
			}
		}
		
//
//    // Find author by name
//    Optional<Author> authorByName = authorRepository.findByName("Author 1");
//    System.out.println("Searching for an author by name: ");
//    authorByName.ifPresent(System.out::println);
//
//    // Search for a book by ID
//    Optional<Book> foundBook = bookRepository.findById(2);
//    foundBook.ifPresent(System.out::println);
//
//    // Search for a book with an invalid ID
//    Optional<Book> notFoundBook = bookRepository.findById(99);
//    notFoundBook.ifPresent(System.out::println);
//
//    // List all books
//    List<Book> books = bookRepository.findAll();
//    System.out.println("Books in database:");
//    books.forEach(System.out::println);
//
//    // Find a book by name
//    Optional<Book> queryBook1 = bookRepository.findByName("Book 2");
//    System.out.println("Query for book 2:");
//    queryBook1.ifPresent(System.out::println);
//
//    // Find a book by name using a named query
//    Optional<Book> queryBook2 = bookRepository.findByNameNamedQuery("Book 3");
//    System.out.println("Query for book 3:");
//    queryBook2.ifPresent(System.out::println);
//
//    // Add a book to author 1
//    Optional<Author> author1 = authorRepository.findById(1);
//    author1.ifPresent(a -> {
//        a.addBook(new Book("Book 4"));
//        System.out.println("Saved author: " + authorRepository.save(a));
//    });
//
    // Close the entity manager and associated factory
    entityManager.close();
    entityManagerFactory.close();

		// Thread dump
//    Thread.getAllStackTraces().forEach((thread, stackTrace) -> {
//        System.out.println("Thread: " + thread.getName() + ", state=" + thread.getState());
//        Arrays.stream(stackTrace).forEach(stackTraceElement -> {
//            System.out.println("\t" + stackTraceElement.toString());
//        });
//    });
	}
}
