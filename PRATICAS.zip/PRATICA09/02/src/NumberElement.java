public interface NumberElement {
    public void sum();
    public int totalSum();
}
