public interface NumberElement {
    public void accept(NumberVisitor visitor);
}
