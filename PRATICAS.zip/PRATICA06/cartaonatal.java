public class CartaoDeNatal {
    String mensagem;

    boolean brasileiro;
    boolean italiano;
    boolean espanhol;

    public static class Builder{
        String mensagem;

       
        boolean brasileiro = false;
        boolean italiano = false;
        boolean espanhol = false;

        public Builder(){}

        public Builder brasileiro(){
            this.brasileiro = true;
            mensagem = "Feliz natal :D ";
            return this;
        }

        public Builder italiano(){
            this.italiano = true;
            mensagem = "buon natale :D";
            return this;
        }

        public Builder espanhol(){
            this.espanhol = "Feliz navidad :D ";
            return this;
        }

        public CartaoDeNatal build(){
            return new CartaoDeNatal(this);
        }
    }

    public CartaoDeNatal(Builder builder){
        this.mensagem = builder.mensagem;
        this.brasileiro = builder.brasileiro;
        this.italiano = builder.italiano;
        this.espanhol = builder.espanhol;
    }

    public String getMensagem() {
        return mensagem;
    }

    public static void main(String[] args) {
        CartaoDeNatal cartao = new CartaoDeNatal.Builder()
                                    .brasileiro()
                                    .build();

        System.out.println(cartao.getMensagem());
    }
}